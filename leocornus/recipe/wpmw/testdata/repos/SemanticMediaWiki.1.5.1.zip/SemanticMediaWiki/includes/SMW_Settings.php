<?php

/**
 * File for backward compatibility with pre SMW 1.5.1.
 * This used to be the main entrypoint for SMW, now moved to SemanticMediaWiki.php
 *
 * @file SMW_Settings.php
 * @ingroup SMW
 *
 * @author Jeroen De Dauw
 */

require_once dirname( __FILE__ ) . '/../SMW_Settings.php';